var ship;





function setup() {
  createCanvas(800, 800);
  ship = new Ship();
}

function draw() {
  background(0);
  ship.render();
  ship.turn();
  ship.update();
  ship.edges();
  
}
function keyReleased(){
	ship.setRotation(0); 
  ship.boosting(false);
}

function keyPressed(){
	if (keyCode ==  RIGHT_ARROW){
    ship.setRotation(0.1);
  }else if (keyCode ==  LEFT_ARROW){
    ship.setRotation(-0.1);
  }if (keyCode == UP_ARROW){
    ship.boosting(true);
  }
}


function Ship() {
  this.position = createVector(width/2, height/2);
  this.r =10;
  this.heading = PI/2;
  this.rotation =0;
  this.velocity = createVector(0,0);
  this.isBoosting = false;
  
  this.update = function(){
    this.position.add(this.velocity);
    this.velocity.mult(0.95);
    if (this.isBoosting){
      this.boost();
    }
  }
  
  
  this.boost = function(){
    var force = p5.Vector.fromAngle(this.heading);
    this.velocity.add(force);
		
  }
  this.boosting = function(bool){
    this.isBoosting = bool;
  }
  
  
  this.render = function(){
    translate(this.position.x, this.position.y);
    rotate(this.heading + PI/2);
    noFill();
    stroke(255);
		triangle(-this.r, 2*this.r, this.r,2*this.r,0, -this.r ); 
    
  }
  
  this.edges = function(){
  	if (this.position.x > width + this.r){
    	this.position.x = -this.r; 
    }else if (this.position.x < -width - this.r){
      this.position.x = width + this.r;
    }
    if (this.position.y > height + this.r){
    	this.position.y = -this.r; 
    }else if (this.position.y < -height - this.r){
      this.position.y = height + this.r;
    }
  }
  
  
  
  this.setRotation = function(a){
   this.rotation = a; 
  }
  
  this.turn = function(){
   this.heading = this.heading + this.rotation;
    
  }
  
  
}  